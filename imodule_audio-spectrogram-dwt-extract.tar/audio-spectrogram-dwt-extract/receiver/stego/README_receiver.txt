Receiver can nhan stego.wav va secret.key tu sender, sau do sua extract_task.py:

  STEGO_FILE = "stego.wav"
  KEY_FILE = "secret.key"

Chay:

  cd ~/stego
  python3 extract_task.py

Ket qua dung la file recovered_secret.png.
