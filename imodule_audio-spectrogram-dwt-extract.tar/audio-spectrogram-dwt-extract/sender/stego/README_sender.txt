Sender co san hai file can gui cho receiver:

  stego.wav
  secret.key

Sau khi receiver bat ssh, gui hai file bang lenh:

  scp ~/stego/stego.wav ~/stego/secret.key ubuntu@receiver:~/stego/
